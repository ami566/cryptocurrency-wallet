package bg.sofia.uni.fmi.mjt.cryptoWallet.exceptions;

public class UserAlreadyExistsException extends Exception {
    public UserAlreadyExistsException(String message) {
        super(message);
    }
}
