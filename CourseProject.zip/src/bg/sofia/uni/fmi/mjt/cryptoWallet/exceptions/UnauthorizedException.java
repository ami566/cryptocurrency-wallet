package bg.sofia.uni.fmi.mjt.cryptoWallet.exceptions;

public class UnauthorizedException extends HttpException {
    public UnauthorizedException(String message) {
        super(message);
    }
}

