package bg.sofia.uni.fmi.mjt.cryptoWallet.exceptions;

public class ForbiddenException extends HttpException {
    public ForbiddenException(String message) {
        super(message);
    }
}
