package bg.sofia.uni.fmi.mjt.cryptoWallet.command;

public record Command(CommandType command, String[] arguments) {
}
