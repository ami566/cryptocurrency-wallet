package bg.sofia.uni.fmi.mjt.cryptoWallet.exceptions;

public class TooManyRequestsException extends HttpException {
    public TooManyRequestsException(String message) {
        super(message);
    }
}
