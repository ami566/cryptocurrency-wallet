package bg.sofia.uni.fmi.mjt.cryptoWallet.exceptions;

public class CryptoCurrencyNotInWalletException extends Exception {
    public CryptoCurrencyNotInWalletException(String message) {
        super(message);
    }
}
