package bg.sofia.uni.fmi.mjt.cryptoWallet.wallet.transaction;

public class DepositMoneyTransaction extends Transaction {
    private double money;

    public DepositMoneyTransaction(double m) {
        money = m;
    }

    public double getMoney() {
        return money;
    }

    @Override
    public String transactionString() {
        return "Deposited " + money + " USD.";
    }
}
