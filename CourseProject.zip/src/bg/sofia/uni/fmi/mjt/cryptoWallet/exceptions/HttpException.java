package bg.sofia.uni.fmi.mjt.cryptoWallet.exceptions;

public class HttpException extends Exception {
    public HttpException(String message) {
        super(message);
    }
}
