package bg.sofia.uni.fmi.mjt.cryptoWallet.exceptions;

public class NoSuchAssetException extends Exception {
    public NoSuchAssetException(String message) {
        super(message);
    }
}
