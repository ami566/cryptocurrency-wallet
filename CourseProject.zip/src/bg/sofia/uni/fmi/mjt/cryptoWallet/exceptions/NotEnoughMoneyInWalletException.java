package bg.sofia.uni.fmi.mjt.cryptoWallet.exceptions;

public class NotEnoughMoneyInWalletException extends Exception {
    public NotEnoughMoneyInWalletException(String message) {
        super(message);
    }
}
