package bg.sofia.uni.fmi.mjt.cryptoWallet.exceptions;

public class NoSuchUserException extends Exception{
    public NoSuchUserException(String message) {
        super(message);
    }
}
